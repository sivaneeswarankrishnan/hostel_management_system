package uthmhostelmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author sivan
 */
public class UTHMHostelManagementSystem {

    public static void main(String[] args) {
        new Login().setVisible(true);
    }
    
}
